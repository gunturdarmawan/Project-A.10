===== PROJECT PABW KELAS A =====

Developer:
    -Guntur darmawan
    -Ligar Wisnu Geogiza
    -Muhammad Ihsan Nurulhuda

Project Name: ....

Description Project: 
    Aplikasi untuk berbasis web untuk menghubungkan pemerintah daerah dengan masyarakat,
    untuk mengatasi masalah di daerah tersebut dengan solusi-solusi yang ada.

UserFlow: 
    User Login, Kemudian masuk kedalam tampilan beranda, dapat melihat masalah yang di-post,
    sesuai daeerah dari user, Kemudian dapat memberi suka atau masukan untuk terkait masalah tersebut.
    3 Solusi terbaik akan, berada di TOP Sulution.

Actor: 
    - Masyarakat Umum
    - Admin atau Pemerintah Daerah.

Assignment (TO-DO):
   ( ) Tampilan Aplikasi memuat HTML CSS JS dan WRD.
   ( ) Erd Sesuai dengan kasus project.
   ( ) Struktur Basis data Sesuai Hasil Konversi.

